More Health Forge 6.0 Universal by nohero

For Minecraft 1.7.10

New in V6.0:

-Enchantment System! Armor items can be enchanted with Hearts I - V (1 to 5 hearts per armor piece). Can be turned off in config. 
-Fixed issue where you can't gain extra hearts if you didn't set a max health cap
-Fixed bug when changing dimensions fully healed you


Forge required! I used forge version 10.13.2.1236 found here: http://files.minecraftforge.net/

Modloader NOT REQUIRED/UNSUPPORTED.

Links in my thread on the forum

---------------------------------------
SSP Installation Instructions
---------------------------------------

1. Install Forge API.

2. Drop the zipped file into the mods folder. (%appdata%\.minecraft\mods)

3. Run minecraft, enjoy! :D

4. Any questions/suggestions, post in the thread!

**Find heart pieces and containers in dungeon chests. Ender dragon and Wither boss both drop one heart container each!
*some mods have heart item functions. I remember tales of kingdom sold them. 
*You can edit the config in better dungeons to add heart containers and pieces

---------------------------------------
SMP Installation Instructions
---------------------------------------

Be sure to install forge!

1. Get the minecraft_server jar from http://minecraft.net/download. Create a new folder and put this jar into it. This will be your server folder.

2. Drag the zipped file into the "mods" folder found where you set up your server. 

3. (optional step) Config folder (in server only folder): you can open this folder to find the config file, which you can change as you wish. It will determine all the settings for the entire server. Everyone will be playing on the same rules (aka no cheating) enforced by the server config. The individual player's config gets overridden when on the server.

4. (optional step) Drag the config folder into your newly created folder (the server folder). Thus, when the server starts, it right away has the changed options (most importantly the multiplier config - it only affects newly generated areas, so if you start the server without dragging the config file, the starting generated area will probably have limited heart containers/items which is not good for server!)

5. Start the server, enjoy :D

6. And questions/suggestions/feedback, please post on the forum, search for nohero more health!



---------------------------------------



Backup your minecraft jar! Might conflict with other mods!


--------------------------------
Configuration File.
--------------------------------

How to:

1. Start up minecraft with this mod.

2.Shut down Minecraft.

3.Open %appdata%/.minecraft/config/nohero_moreHealth.cfg with a program like notepad. (Note you have to run minecraft once after installing mod for this file to pop up).

3 (server) if on server, the config (if you didn't drag it) will auto generate in the server jar's folder.

4.Do not edit the lines starting with #! they are just comments!
You have two things you can configure yourself, anyway you want!

LevelRamp=1,3,5,6,7,8... (Set the levels you want to gain hearts on! <default> below)
StartingHearts=20 (change the starting hearts, from 1 to 20), default 10. 

5. Start Minecraft, enjoy! These config settings will affect ALL your worlds.

HUD Options Information:

Minimal HUD: Heart info is displayed in one row on the left side, with armor row above it. Your heart row is denoted to the left of the heart row. EG If the HUD displays 3 hearts but there is a "2" to the left, you are on row 2 meaning you have a total of 13 hearts.
More Health HUD: Custom hud that places armor bar on top of food. 

Set both of these options to false to get minecraft's default HUD OR if you are having issues with other HUD/GUI mods.


More health RPG:

Level Up to gain more health!

You get hearts based on this <default> ramp:

Lvl 1: Gain 1 Heart, 11 hearts total
Lvl 4: 12 hearts total
Lvl 10: 13 
lvl 15: 14 
lvl 20: 15 
lvl 25: 16 
lvl 30: 17 
lvl 34: 18 
lvl 38: 19 
lvl 42: 20 
lvl 46: 21 
lvl 50: 22 
lvl 53: 23 
lvl 56: 24 
lvl 59: 25
lvl 62: 26
lvl 64: 27
lvl 66: 28
lvl 68: 29
lvl 70: 30 hearts

When you DIE or if you ENCHANT an item, you lose experience. HOWEVER, you will NOT lose your hearts!
Aka, if you got to lvl 14, you would have 16 hearts. If you die, you would STILL have 16 hearts, but you will have
to work your way up the levels to gain hearts again (aka to get to 17 hearts you have to get to lvl 18.)




